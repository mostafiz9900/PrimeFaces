package org.primefaces.cookbook.controller.chapter6;

import javax.faces.view.ViewScoped;
import javax.inject.Named;

/**
 * PanelMenuBean
 *
 * @author  Oleg Varaksin / last modified by $Author: $
 * @version $Revision: 1.0 $
 */
@Named
@ViewScoped
public class PanelMenuBean extends BaseMenuBean {
}
